#!/usr/bin/php
<?php
/**
 *   ./example3.php result "monitor;Zombie processes" 0 --output "Some output"
 */
define('MONITOR_HOST', '<your monitor host>');
define('MONITOR_USER', '<your monitor user>');
define('MONITOR_PASS', '<your monitor pass>');
define('MONITOR_SSL', false); // Set to true if you have a valid SSL cert

if (count($argv) < 3) {
  echo "Monitor Remote expects atleast two parameters supplied, an action and an identifier\n";
  exit(1);
}

/**
 * Generalized curl execution function that only takes the command to execute
 * and the data to send.
 *
 * @param  string $command  The command to use
 * @param  array  $data     The data to send
 * @return void
 */
function remote_call ($command, array $data) {

  $url = sprintf('https://%s/api/command/%s', MONITOR_HOST, $command);

  $jsondata = json_encode($data);
  $handle = curl_init($url);

  curl_setopt($handle, CURLOPT_USERPWD, MONITOR_USER . ':' . MONITOR_PASS);
  curl_setopt($handle, CURLOPT_POST, 1);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($handle, CURLOPT_POSTFIELDS, $jsondata);
  curl_setopt($handle, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

  if (MONITOR_SSL === false) {
    curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
  }

  $result = curl_exec($handle);

  if ($result) {
    $result = json_decode($result, true);
    if ($result['error']) {
      echo $result['error'] . "\n";
      echo $result['full_error'] . "\n";
      exit(1);
    }  elseif ($result['result']) {
      echo $result['result'] . "\n";
      echo "Using data: \n";
      array_walk($data, function ($v, $k) {
        echo sprintf("  %s : %s\n", $k, $v);
      });
    }
  } else {
    echo "Failed to execute cURL request\n";
    exit(1);
  }

}

/**
 * Monitor remote functions.
 *
 * This section contains the functions that handle context specific behaviours.
 */

/**
 * Submits a passive service check result using the op5 Monitor
 * PROCESS_SERVICE_CHECK_RESULT endpoint of the HTTP API
 *
 * @param  string $host        The host
 * @param  string $service     The service
 * @param  array  $parameters  The parameters to use
 * @return void
 */
function service_result ($host, $service, $parameters) {

  $state = (isset($parameters[0]) && is_numeric($parameters[0])) ? intval($parameters[0]) : false;
  $output = (isset($parameters[1])) ? $parameters[1] : '';

  remote_call('PROCESS_SERVICE_CHECK_RESULT', array(
    "host_name" => $host,
    "service_description" => $service,
    "status_code" => $state,
    "plugin_output" => $output
  ));

}

/**
 * Submits a passive host check result using the op5 Monitor
 * PROCESS_HOST_CHECK_RESULT endpoint of the HTTP API
 *
 * @param  string $host        The host
 * @param  array  $parameters  The parameters to use
 * @return void
 */
function host_result ($host, $parameters) {

  $state = (isset($parameters[0]) && is_numeric($parameters[0])) ? intval($parameters[0]) : false;
  $output = (isset($parameters[1])) ? $parameters[1] : '';

  remote_call('PROCESS_SERVICE_CHECK_RESULT', array(
    "host_name" => $host,
    "status_code" => $state,
    "plugin_output" => $output
  ));

}

/**
 * Submits an acknowledge to op5 Monitor ACKNOWLEDGE_HOST_PROBLEM
 * endpoint of the HTTP API
 *
 * @param  string $host        The host
 * @param  array  $parameters  The parameters to use
 * @return void
 */
function host_ack ($host, $parameters) {

  $comment = (isset($parameters[0])) ? $parameters[0] : 'Acknowledged by Monitor Remote';
  remote_call('ACKNOWLEDGE_HOST_PROBLEM', array(
    "host_name" => $host,
    "comment" => $comment,
    "sticky" => 1,
    "notify" => true,
    "persistent" => true
  ));

}

/**
 * Submits an acknowledge to op5 Monitor ACKNOWLEDGE_SVC_PROBLEM
 * endpoint of the HTTP API
 *
 * @param  string $host        The host
 * @param  string $service     The service
 * @param  array  $parameters  The parameters to use
 * @return void
 */
function service_ack ($host, $service, $parameters) {

  $comment = (isset($parameters[0])) ? $parameters[0] : 'Acknowledged by Monitor Remote';
  remote_call('ACKNOWLEDGE_SVC_PROBLEM', array(
    "host_name" => $host,
    "service_description" => $service,
    "comment" => $comment,
    "sticky" => 1,
    "notify" => true,
    "persistent" => true
  ));

}

/**
 * Identify required parameters, action and identifier, and invoke proper function
 * for the execution.
 */
$action = $argv[1];
$identifier = explode(';', $argv[2]);

$host = $identifier[0];
$service = (isset($identifier[1])) ? $identifier[1] : false;

$parameters = array_slice($argv, 3);
$context = ($service) ? 'service' : 'host';
$caller = strtolower($context . '_' . $action);

if (function_exists($caller)) {
  if ($service) {
    call_user_func_array($caller, array($host, $service, $parameters));
  } else {
    call_user_func_array($caller, array($host, $parameters));
  }
} else {
  echo sprintf("No action '%s' on context '%s' available\n", $action, $context);
  exit(1);
}