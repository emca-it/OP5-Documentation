#!/usr/bin/perl -w
#
# $Id: notify_delay_spool.pl,v 1.0 2014/07/10 13:00:31 daniel Exp $
#
# notify.pl - Delayed notification spooling script for OP5 Monitor
#
# Author: Daniel Jerverén <dj@op5.se>
#
# Copyright(C) 2014 OP5 AB
# All rights reserved.
#

use strict;

my $tempfile = "msg." . time() . "\.$$";
my $spooldir = "/opt/monitor/var/spool/notify_delay";

# Simply dump the notification macros to spool file.
open(OUT,">$spooldir/$tempfile") or die $!;
foreach my $line (@ARGV) {
	print OUT "$line\n";
}
close(OUT);
