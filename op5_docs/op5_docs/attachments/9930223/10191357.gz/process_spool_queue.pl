#!/usr/bin/perl -w
#
# $Id: process_spool_queue.pl,v 1.0 2014/07/10 16:02:16 daniel Exp $
#
# notify.pl - Delayed notification spool processing script for OP5 Monitor
#
# Author: Daniel Jerverén <dj@op5.se>
#
# Copyright(C) 2014 OP5 AB
# All rights reserved.
#

use strict;
use POSIX qw(strftime);
use File::Glob ':glob';

my $runtime = strftime "%H:%M", localtime;
my $cmdpipe = "/opt/monitor/var/rw/nagios.cmd";
my $spooldir = "/opt/monitor/var/spool/notify_delay";


# Loop through all spool files.
my @files = glob("$spooldir/msg.*");
foreach my $file (@files) {
	my %data = ();

	# Collect notification data as key => value in %data hash.
	open(IN,"$file") or die $!;
	while (<IN>) {
		chomp;
		my @str = split('=',$_,2);
		$data{$str[0]} = $str[1];
	}
	close(IN);

	# Ignore file if SEND time doesn't match start time.
	next if ($runtime ne $data{SEND}); 

	# Send custom notification depending on type.
	my $time = time();
	open(OUT, ">$cmdpipe") or die $!;
	if ($data{SERVICEDESC}) {
		print OUT "[$time] SEND_CUSTOM_SVC_NOTIFICATION;" .
			"$data{HOSTNAME};" .
			"$data{SERVICEDESC};" .
			"$data{NOTIFICATIONTYPE};" .
			"$data{CONTACTNAME};" .
			"Original alert: [$data{SHORTDATETIME}] " .
			"$data{SERVICEDESC} $data{SERVICESTATE}: $data{SERVICEOUTPUT}\n"; 
	} else {
		print OUT "[$time] SEND_CUSTOM_HOST_NOTIFICATION;" .
			"$data{HOSTNAME};" .
			"$data{NOTIFICATIONTYPE};" .
			"$data{CONTACTNAME};" .
			"Original alert: [$data{SHORTDATETIME}] " .
			"$data{HOSTNAME} $data{HOSTSTATE}: $data{HOSTOUTPUT}\n";
	}
	close(OUT);
	unlink($file);
}
exit;
