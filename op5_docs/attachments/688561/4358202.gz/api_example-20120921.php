<?php
/*
 Author: op5 AB
 Date : 27/08/2012
 Description: This example shown here demonstrates
 the basics of how to communicate with the Monitor HTTP API.
*/

# Credentials for a user with read-access for the object
# you wish to fetch data from.
$username = '<username>'; // must be a user with at least read-access.
$password = '<password>';

# API endpoint, see the full API documentation at http://<your-host>/api/help
$uri = "<url-to-monitor>"; // URL to your monitor-instance, ending with /api/, example: http://monitor.mycompany.com/api/

# Host to generate service report on
# Specify the alias/address of the host here.
$host = "<name-of-host>";

# Prepare curl execution and wrap it into a re-useable function.
function DoRequest($text) {
        global $username, $password, $uri;

        # Json-formated responses is preferred.
        $c = curl_init("$uri$text?format=json");

        curl_setopt($c, CURLOPT_USERPWD, "$username:$password");
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        
        # in-case you have not installed the SSL certificate properly.
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
        
        $response = curl_exec($c);
        $json = json_decode($response);
        curl_close($c);
        
        return $json;
}

# Fire the request and receive the services information.
$status = DoRequest("status/host/$host");
$host_name = $status->name;

# Count total services for host
$total_host_services = count($status->services_with_info);

# Count amount of services that are in OK/WARNING/CRITICAL/UNKNOWN-state
$services_ok = 0;
$services_warning = 0;
$services_critical = 0;
$services_unknown = 0;
foreach ($status->services_with_info as $services) {
        if ($services[1] == 0) {
                $services_ok++;
        } elseif ($services[1] == 1) {
                $services_warning++;
        } elseif ($services[1] == 2) {
                $services_critical++;
        } elseif ($services[1] == 3) {
                $services_unknown++;
        }
}

# Print information
echo <<<INFO
	<h2>op5 Monitor HTTP API example</h2>
	The report below will give you an overview of services and their state that belong to host: <u>$host_name</u><br /><br />
	Total services: <strong>$total_host_services</strong> <br />
	&nbsp;&nbsp;&nbsp;$services_ok services are in <font color="green">OK</font> state <br />
	&nbsp;&nbsp;&nbsp;$services_warning services are in <font color="yellow">WARNING</font> state<br />
	&nbsp;&nbsp;&nbsp;$services_critical services are in  <font color="red">CRITICAL</font> state<br />
	&nbsp;&nbsp;&nbsp;$services_unknown services are in <font color="orange">UNKNOWN</font> state<br />
	<hr>
INFO;

# Print all services with their name, state
# and latest status information.
echo "<pre>";
foreach ($status->services_with_info as $service) {
        if ($service[1] == 0) {
                $state = "OK";
                echo "Service: <font color=\"green\">$service[0]</font><br />";
                echo "State: $service[1] ($state) <br />";
                echo "Status information: $service[3]<br /><br />";
        } elseif ($service[1] == 1) {
                $state = "WARNING";
                echo "Service: <font color=\"yellow\">$service[0]</font><br />";
                echo "State: $service[1] ($state) <br />";
                echo "Status information: $service[3]<br /><br />";
        } elseif ($service[1] == 2) {
                $state = "CRITICAL";
                echo "Service: <font color=\"red\">$service[0]</font><br />";
                echo "State: $service[1] ($state) <br />";
                echo "Status information: $service[3]<br /><br />";
        } elseif ($service[1] == 3) {
                $state = "UNKNOWN";
                echo "Service: <font color=\"orange\">$service[0]</font><br />";
                echo "State: $service[1] ($state) <br />";
                echo "Status information: $service[3]<br /><br />";
        }
}
echo "</pre>";
?> 
