#!/bin/bash
#
# quick hack to get data for all CPU cores from sar into nagios perfdata
# by mattias.bergsten@op5.com
#
export LANG=en_US.UTF-8
echo -n "OK |"
sar -P ALL 1 1 | tail -n +4 | head -n +13 | awk '{ print "\x27" $3 "-user\x27=" $4 "% " "\x27" $3 "-nice\x27=" $5 "% " "\x27" $3 "-system\x27=" $6 "% " "\x27" $3 "-iowait\x27=" $7 "% " "\x27" $3 "-steal\x27=" $8 "% " "\x27" $3 "-idle\x27=" $9 "%" }' | tr '\n' ' '
echo ""

