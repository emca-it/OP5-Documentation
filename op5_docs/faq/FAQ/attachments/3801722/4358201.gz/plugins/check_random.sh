#!/bin/bash
#
# quick hack to generate random check results for nagios load testing
# by mattias.bergsten@op5.com
#
seed=$((RANDOM%10))
randsleep=$((RANDOM%15))

case $seed in
[0-7])
	sleep $randsleep
	echo "OK - Slept for $randsleep seconds|'seed'=$seed;15;20;0;10 'randsleep'=$randsleep;20;25;0;15"
	exit 0
	;;
8)
	sleep $randsleep
	echo "WARNING - Slept for $randsleep seconds|'seed'=$seed;15;20;0;10 'randsleep'=$randsleep;20;25;0;15"
	exit 1
	;;
9)
	sleep $randsleep
	echo "CRITICAL - Slept for $randsleep seconds|'seed'=$seed;15;20;0;10 'randsleep'=$randsleep;20;25;0;15"
	exit 2
	;;
10)
	sleep $randsleep
	echo "UNKNOWN - Slept for $randsleep seconds|'seed'=$seed;15;20;0;10 'randsleep'=$randsleep;20;25;0;15"
	exit 3
	;;
esac
