<?php

/*
* Adapted for check_all_cpu.sh by mattias.bergsten@op5.com from a template by
* Jason Hancock for his check_mem plugin. His copyright notice follows:
*
* Copyright (c) 2012 Jason Hancock <jsnbyh@gmail.com>
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is furnished
* to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*
* This file is part of the nagios-puppet bundle that can be found
* at https://github.com/jasonhancock/nagios-memory
*/

$alpha = 'CC';

$colors = array(
    '#850707' . $alpha,
    '#FFDB87' . $alpha,
    '#25345C' . $alpha,
    '#88008A' . $alpha,
    '#4F7774' . $alpha,
    '#000000' . $alpha,
);

$numgraph = 1;

foreach ($DS as $i => $value) {

$dsparts = explode("-", $NAME[$i]);
$cpu = $dsparts[0];
$type = $dsparts[1];

$mydata[$cpu][$type] = $i;

}

foreach ($mydata as $mycpu => $data) {

$count = 0;
$item = 1;
$def[$numgraph] = '';

  $opt[$numgraph] = sprintf('-T 55 -l 0 --vertical-label "%%" --title "%s / CPU Usage core %s "', $hostname, $mycpu);
  $ds_name[$numgraph] = "CPU Usage core " . $mycpu;

	foreach ($data as $mytype => $index) {

		$def[$numgraph] .= rrd::def("var$item", $RRDFILE[$index], $DS[$index], 'AVERAGE');

		    if ($item == '1') {
		        $def[$numgraph] .= rrd::area ("var$item", $colors[$count], "$mytype", 15);
		    } else {
		        $def[$numgraph] .= rrd::area ("var$item", $colors[$count], "$mytype", 15, 'STACK');
		    }

    $def[$numgraph] .= rrd::gprint ("var$item", array('LAST','MAX','AVERAGE'), "%4.2lf %s\\t");

    $count++;
    $item++;
	}
    $numgraph++;
}
