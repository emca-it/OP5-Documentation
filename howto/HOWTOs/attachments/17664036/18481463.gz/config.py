servicenow_settings = dict(
    instance = 'devxxx', # the instance name without .service-now.com. This becomes devxxx.service-now.com
    username = 'admin',
    password = 'somepassword'
)

servicenow_fields = dict(
    caller = 'Fred Luddy', # the caller who should be assigned, can be removed/left empty
    category = 'Software', # the category the incidents should be placed in
    location = 'op5 Monitor', # the location, can be removed/left empty
    severity = '2', # the severity of all incidents sent from op5
    priority = '1',# the priority of all incidents sent from op5
    urgency = '2', # the urgency of all incidents sent from op5
    impact = '1', # the impact of all incidents sent from op5
    assigned_to = 'Fred Luddy' # the assignee for all incidents, can be removed/left empty
)
