#!/usr/bin/python
# -*- coding: utf-8 -*-
# Integrates op5 Monitor with ServiceNow

__author__ = "Misiu Pajor"
__credits__ = ["Robert Wikman"]
__license__ = "GPL"
__version__ = "0.2"
__maintainer__ = "Misiu Pajor"
__email__ = "misiu.pajor@op5.com"

import pysnow, sys, config, logging
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
logging.basicConfig(level=logging.DEBUG, filename='/opt/plugins/custom/integrations/servicenow/debug.log')

"""
Handles all nagios/naemon arguments passed to the script. eg. "hostname, lasthoststatechange"
"""
def get_args():
        if len(sys.argv) < 2:
            sys.exit("Bailing out. This script needs at least two arguments passed to it. Please consult the README packaged with this script.")
        if sys.argv[1] == "-h" or sys.argv[1] == "--help":
            sys.exit("Please consult the README packaged with this script")
        args = dict(arg.split('=') for arg in sys.argv[1:])
        return args

def create_template(args):
    object_type = "SERVICE"
    # all arguments that consist of multiple dollar signs (eg. $HOSTSTATE$) that op5 did
    # not expand they will be set to N/A
    for k, v in args.iteritems():
        if len(v.split("$")) - 1 == 2:
            args[k] = "N/A"

    # check to see if this is a host or service alert
    if args["SERVICEDESC"] == "N/A": object_type = "HOST"
    # define standard alert template
    config.servicenow_fields["HOSTNAME"] = args["HOSTNAME"]
    config.servicenow_fields["HOSTSTATE"] = args["HOSTSTATE"]
    config.servicenow_fields["HOSTADDRESS"] = args["HOSTADDRESS"]
    config.servicenow_fields["LONGDATETIME"] = args["LONGDATETIME"]

    # host alert template
    if object_type == "HOST":
        config.servicenow_fields["short_description"] = """{HOSTNAME} - {HOSTOUTPUT}""".format(**args)
        config.servicenow_fields["HOSTOUTPUT"] = args["HOSTOUTPUT"]
        config.servicenow_fields["comments"] = """
        HOST ALERT FROM OP5 MONITOR:
        Host: {HOSTNAME}
        Address: {HOSTADDRESS}
        State: {HOSTSTATE}
        Date: {LONGDATETIME}
        Output: {HOSTOUTPUT}

        Alert recieved from node: {NODE}""".format(**args)

    # modify alert template for service alerts
    if object_type == "SERVICE":
        config.servicenow_fields["short_description"] = """{HOSTNAME} - {SERVICEDESC} is {SERVICESTATE}""".format(**args)
        config.servicenow_fields["comments"] = """
        SERVICE ALERT FROM OP5 MONITOR:
        Host: {HOSTNAME}
        Address: {HOSTADDRESS}

        Service: {SERVICEDESC}
        State: {SERVICESTATE}
        Date: {LONGDATETIME}
        Output: {SERVICEOUTPUT}

        Alert recieved from node: {NODE}""".format(**args)

    return config.servicenow_fields

if __name__ == "__main__":
    args = get_args()
    #logging.debug('OP5 arguments received:\n%s\n', args)
    #logging.debug('Configuration settings from config.py:\n%s\n', config.servicenow_settings)

    # create client object
    s = pysnow.Client(instance=config.servicenow_settings["instance"],
                      user=config.servicenow_settings["username"],
                      password=config.servicenow_settings["password"],
                      raise_on_empty=True)

    data = create_template(args)
    # create a new incident
    result = s.insert(table='incident', payload=data)
    #logging.debug("Incident number >%s< was successfully created with ServiceNow.\n", result["number"])
    #logging.debug("Response from ServiceNow after incident creation:\n%s\n", result)

